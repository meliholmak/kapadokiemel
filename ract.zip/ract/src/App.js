import React from 'react';
import './App.css';
import profilFoto from './profil.jpg';

function App() {
  const egitim = [
    { kurum: 'Kapadokya Üniversitesi Bilgisayar Programcılığı', yil: '2023 / -' },
    { kurum: 'İstanbul Üniversitesi Açık öğretim Fakültesi Sosyal Hizmetler', yil: '2024 / -' },
  ];

  const isDeneyimi = [
    { sirket: 'Olmak Game', pozisyon: 'Oyun Tasarımı', yil: '2021-2022' },
    { sirket: 'E-ticaret sitesi', pozisyon: 'E-ticaret Model Tasarımı', yil: '2021-2023' },
  ];

  const hobiler = ['Kitap Yazmak', 'Oyun Geliştirme', 'Yazılım'];

  return (
    <div className="cv">
      <div className="kisisel-bilgiler">
        <img src={profilFoto} alt="Profil Fotoğrafı" />
        <h1>Melih Peksen</h1>
        <p>Tasarım ve Yazılım Senior Developer</p>
        <p>Email: gmail@gmail.com</p>
        <p>Telefon: +90 555555555</p>
        <div className="social-icons">
          <a href="https://www.linkedin.com/in/melihpeksen" className="social-button">
            LinkedIn
          </a>
          <a href="https://www.instagram.com/ciddili_mizah" className="social-button">
            Instagram
          </a>
          <a href="https://github.com/meliholmak" className="social-button">
            GitHub
          </a>
        </div>
      </div>

      <div className="egitim-bilgileri">
        <h2>Eğitim</h2>
        <ul>
          {egitim.map((egitim) => (
            <li key={egitim.kurum}>
              {egitim.kurum} ({egitim.yil})
            </li>
          ))}
        </ul>
      </div>

      <div className="is-deneyimi">
        <h2>İş Deneyimleri</h2>
        <ul>
          {isDeneyimi.map((is) => (
            <li key={is.sirket}>
              {is.sirket} - {is.pozisyon} ({is.yil})
            </li>
          ))}
        </ul>
      </div>

      <div className="yetenekler">
        <h2>Yetenekler</h2>
        <p>
          Adobe Cloud, Microsoft Office, Blender, C#, HTML, PHP program ve kodlama dillerinde bilgiliyim.
        </p>
      </div>

      <div className="hobiler">
        <h2>Hobiler ve İlgi Alanları:</h2>
        <ul>
          {hobiler.map((hobi) => (
            <li key={hobi}>{hobi}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default App;