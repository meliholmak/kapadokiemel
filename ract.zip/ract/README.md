# React CV Uygulaması

Proje, React kodlama dili ile yazılmıştır.

## Özellikler

* Kişisel bilgiler, eğitim bilgileri, iş deneyimi.
* Sosyal medya ikonları ile hesaplara bağlantı.

## Kurulum

1. Gerekli paketleri yükleyin: `npm install`
2. Uygulamayı başlatın: `npm start`

## Kullanım

* `src/App.js` dosyasında CV bilgilerinizi güncelleyin.
* `src/App.css` dosyasında stil değişiklikleri yapabilirsiniz.

